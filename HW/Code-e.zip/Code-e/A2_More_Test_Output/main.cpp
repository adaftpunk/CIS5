/*
 * File:   main.cpp
 * Author: Garrett Hileman
 * Created: March 03, 2022, 10:55 PM
 * Purpose: More Test Output
 */
//System Libraries

#include <iostream> //Input/Output Library
#include <iomanip> //Format Library

using namespace std;

//User Libraries

//Global Constants
//Physics/Chemistry/Math/Conversion Higher Dimension Only

//Function Prototypes

// Program Execution Begins here
int main(int argc, char** argv) {
    //Set the Random Number Seed
    
    //Declare Variables
    float num1, //First variable entered
          num2, //Second variable entered
          num3, //Third variable entered
          num4; //Fourth variable entered
    
    //Initial Variables
    
    //Map the inputs to the outputs
    cin>>num1>>num2>>num3>>num4;
    
    //Display the inputs and outputs
    cout<<fixed<<setprecision(0);
    
    cout<<setw(9)<<num1<<
          setw(10)<<setprecision(1)<<num1<<
          setw(10)<<setprecision(2)<<num1<<endl;
    
    cout<<setw(9)<<setprecision(0)<<num2<<
          setw(10)<<setprecision(1)<<num2<<
          setw(10)<<setprecision(2)<<num2<<endl;
    
    cout<<setw(9)<<setprecision(0)<<num3<<
          setw(10)<<setprecision(1)<<num3<<
          setw(10)<<setprecision(2)<<num3<<endl;
    
    cout<<setw(9)<<setprecision(0)<<num4<<
          setw(10)<<setprecision(1)<<num4<<
          setw(10)<<setprecision(2)<<num4;

    
    //Exit the code
    return 0;
}

