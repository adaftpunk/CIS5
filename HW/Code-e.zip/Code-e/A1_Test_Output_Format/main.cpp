/*
 * File:   main.cpp
 * Author: Garrett Hileman
 * Created on March 3, 2022, 9:39 PM
 * Purpose: Test Output Format
 */
//System Libraries

#include <iostream> //Input/Output Library

using namespace std;

//User Libraries

//Global Constants
//Physics/Chemistry/Math/Conversion Higher Dimension Only

//Function Prototypes

// Program Execution Begins here
int main(int argc, char** argv) {
    //Set the Random Number Seed
    
    //Declare Variables
    int num;
    float fnum;
    
    //Initial Variables
    
    //Map the inputs to the outputs
   cin>>num>>fnum;
    
    //Display the inputs and outputs
    cout<<num<<endl;
    cout<<fnum<<endl;
    cout<<"Hello World     "<<endl; 
    cout<<"\tTab it!"<<endl;
    cout<<"Compare . . . to space   ";
    
    //Exit the code
    return 0;
}

