/*
 * File:   main.cpp
 * Author: Garrett Hileman
 * Created on March 16, 2022, 8:20 PM
 * Purpose: Insurance
 */
//System Libraries

#include <iostream> //Input/Output Library

using namespace std;

//User Libraries

//Global Constants
//Physics/Chemistry/Math/Conversion Higher Dimension Only

//Function Prototypes

// Program Execution Begins here
int main(int argc, char** argv) {
    //Set the Random Number Seed
    
    //Declare Variables
    float houWor, //House Worth
          Insu;  //Insurance needed  
    
    //Initial Variables
    cout<<"Insurance Calculator"<<endl;
    cout<<"How much is your house worth?"<<endl;
    cin>>houWor;
    
    //Map the inputs to the outputs
    Insu=houWor*0.80;
    //Display the inputs and outputs
    cout<<"You need $"<<Insu<<" of insurance.";
    
    //Exit the code
    return 0;
}

