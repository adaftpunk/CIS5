/*
 * File:   main.cpp
 * Author: Garrett Hileman
 * Created on March 09, 2022, 10:06 PM
 * Purpose: Calorie Counter
 */
//System Libraries

#include <iostream> //Input/Output Library
#include <iomanip>  //Format Library

using namespace std;

//User Libraries

//Global Constants
//Physics/Chemistry/Math/Conversion Higher Dimension Only

//Function Prototypes

// Program Execution Begins here
int main(int argc, char** argv) {
    //Set the Random Number Seed
    
    //Declare Variables
          int BAG,     //full bag of cookies
              SERV,    //how many servings in a bag  
              SERVCAL; //calories in a serving 
    float calCnsm, //calories consumed
          ckisAte, //cookies ate
          servAte, //servings ate
          ckisServ; //cookies in a serving
    
    //Initial Variables
    cout<<"Calorie"<<setw(8)<<"Counter"<<endl;
    cout<<"How"<<setw(5)<<"many"<<setw(8)<<"cookies"
            <<setw(4)<<"did"<<setw(4)<<"you"<<setw(5)<<"eat?"<<endl;
    cin>>ckisAte;
    
    //Map the inputs to the outputs
    BAG=40;
    SERV=10;
    SERVCAL=300;
    
    ckisServ=BAG/SERV;
    servAte=ckisAte/ckisServ;
    calCnsm=servAte*SERVCAL;
    
    //Display the inputs and outputs
    cout<<"You"<<setw(9)<<"consumed"<<setw(4)
            <<calCnsm<<setw(10)<<"calories.";
    
    //Exit the code
    return 0;
}