/*
 * File:   main.cpp
 * Author: Garrett Hileman
 * Created on March 14, 2022, 2:19 PM
 * Purpose: Pay
 */
//System Libraries

#include <iostream> //Input/Output Library
#include <iomanip> //Format Library

using namespace std;

//User Libraries

//Global Constants
//Physics/Chemistry/Math/Conversion Higher Dimension Only

//Function Prototypes

// Program Execution Begins here
int main(int argc, char** argv) {
    //Set the Random Number Seed
    
    //Declare Variables
    float payIn,    //Pay increase
          preSal,   //Previous annual salary
          retroPay, //Retroactive pay due 
          nwAnSal,  //New annual pay
          nwMoSal;  //New monthly salary 
            
    
    //Initial Variables
    cout<<"Input"<<setw(9)<<"previous"<<setw(7)
            <<"annual"<<setw(8)<<"salary."<<endl;
    cin>>preSal;
    
    //Map the inputs to the outputs
     payIn=0.076;
     nwAnSal=preSal*payIn+preSal;
     retroPay=(nwAnSal-preSal)/2;
     nwMoSal=nwAnSal/12;        
    
    //Display the inputs and outputs
    cout<<fixed<<setprecision(2); 
    cout<<"Retroactive"<<setw(4)<<"pay"<<setw(5)<<"="<<setw(2)<<"$"<<setw(7)
            <<retroPay<<endl;
    cout<<"New"<<setw(7)<<"annual"<<setw(7)<<"salary"<<setw(3)<<"="<<setw(2)
            <<"$"<<nwAnSal<<endl;
    cout<<"New"<<setw(8)<<"monthly"<<setw(7)<<"salary"<<setw(2)<<"="<<setw(2)
            <<"$"<<setw(7)<<nwMoSal;

    
    //Exit the code
    return 0;
}

