/*
 * File:   main.cpp
 * Author: Garrett Hileman
 * Created on March 3, 2022, 11:35 AM
 * Purpose: Sums
 */
//System Libraries

#include <iostream> //Input/Output Library
#include <iomanip> //Format Library

using namespace std;

//User Libraries

//Global Constants
//Physics/Chemistry/Math/Conversion Higher Dimension Only

//Function Prototypes

// Program Execution Begins here
int main(int argc, char** argv) {
    //Set the Random Number Seed
    
    //Declare Variables
    float negSum,//Negative integer sum
          posSum,//Positive integer sum
          totlSum,//Total integer Sum
          input;//Integer to input 10 times
    
    //Initial Variables
    negSum=posSum=totlSum=0;
    
    //Map the inputs to the outputs
    cout<<"Input"<<setw(3)<<"10"<<setw(9)<<"numbers,"<<setw(4)<<"any"<<setw(7)<<"order,"<<setw(9)<<"positive"<<setw(3)<<"or"<<setw(9)<<"negative"<<endl;
    
    
    cin>>input;
    negSum += input>0?0:input;//Example of Ternary Operator
    posSum += input>0?input:0;//Another example of Ternary Operator
    
   
    cin>>input;
    negSum += input>0?0:input;//Example of Ternary Operator
    posSum += input>0?input:0;//Another example of Ternary Operator
    
    
    cin>>input;
    negSum += input>0?0:input;//Example of Ternary Operator
    posSum += input>0?input:0;//Another example of Ternary Operator
    
    
    cin>>input;
    negSum += input>0?0:input;//Example of Ternary Operator
    posSum += input>0?input:0;//Another example of Ternary Operator
    
   
    cin>>input;
    negSum += input>0?0:input;//Example of Ternary Operator
    posSum += input>0?input:0;//Another example of Ternary Operator
    
    
    cin>>input;
    negSum += input>0?0:input;//Example of Ternary Operator
    posSum += input>0?input:0;//Another example of Ternary Operator
    
    
    cin>>input;
    negSum += input>0?0:input;//Example of Ternary Operator
    posSum += input>0?input:0;//Another example of Ternary Operator
    
    
    cin>>input;
    negSum += input>0?0:input;//Example of Ternary Operator
    posSum += input>0?input:0;//Another example of Ternary Operator
    
    
    cin>>input;
    negSum += input>0?0:input;//Example of Ternary Operator
    posSum += input>0?input:0;//Another example of Ternary Operator
    
 
    cin>>input;
    negSum += input>0?0:input;//Example of Ternary Operator
    posSum += input>0?input:0;//Another example of Ternary Operator
    
    
    //Display the inputs and outputs
    cout<<"Negative"<<setw(4)<<"sum"<<setw(2)<<"="<<setw(4)<<negSum<<endl;
    cout<<"Positive"<<setw(4)<<"sum"<<setw(2)<<"="<<setw(4)<<posSum<<endl;
    cout<<"Total sum    =   "<<totlSum;
    
    //Exit the code
    return 0;
}

