/*
 * File:   main.cpp
 * Author: Garrett Hileman
 * Created on March 09, 2022, 9:12 PM
 * Purpose: Averages
 */
//System Libraries

#include <iostream> //Input/Output Library
#include <iomanip> //Format Library

using namespace std;

//User Libraries

//Global Constants
//Physics/Chemistry/Math/Conversion Higher Dimension Only

//Function Prototypes

// Program Execution Begins here
int main(int argc, char** argv) {
    //Set the Random Number Seed
    
    //Declare Variables
    float Test1, // test 1 score
          Test2, //test 2 score
          Test3, //test 3
          Test4, // test 4 score
          Test5, // test 5 score
          average; //Average of the five numbers
    int numVal; //Number of variables
    
    //Initial Variables  
  cout<<"Input"<<setw(2)<<"5"<<setw(8)<<"numbers"<<setw(3)<<"to"<<setw(9)<<"average."<<endl;
  cin>>Test1>>Test2>>Test3>>Test4>>Test5;
   
    //Map the inputs to the outputs
   numVal=5;
   average=(Test1+Test2+Test3+Test4+Test5)/numVal;
    
    //Display the inputs and outputs
   cout<<fixed<<setprecision(1);
   cout<<"The"<<setw(8)<<"average"<<setw(2)<<"="<<setw(4)<<average;
    
    //Exit the code
    return 0;
}

