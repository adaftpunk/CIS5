/*
 * File:   main.cpp
 * Author: Garrett Hileman
 * Created on March 14, 2022, 3:44 PM
 * Purpose: Room Occupancy
 */
//System Libraries

#include <iostream> //Input/Output Library

using namespace std;

//User Libraries

//Global Constants
//Physics/Chemistry/Math/Conversion Higher Dimension Only

//Function Prototypes

// Program Execution Begins here
int main(int argc, char** argv) {
    //Set the Random Number Seed
    
    //Declare Variables
    int maxCap, //Max capacity of room
        numPpl; //Number of people attending
    
    //Initial Variables
    cout<<"Input the maximum room capacity and the number of people"<<endl;
    
    cin>>maxCap>>numPpl;
    
    //Map the inputs to the outputs

    
    //Display the inputs and outputs
     if ( maxCap < numPpl )
     {
         cout<<"Meeting cannot be held."<<endl;  
         cout<<"Reduce number of people by "<<numPpl-maxCap
                 <<" to avoid fire violation.";
     }
     
     if ( maxCap >= numPpl )
     {
          cout<<"Meeting can be held."<<endl;
          cout<<"Increase number of people by "<<maxCap-numPpl
                  <<" will be allowed without violation.";
     }   
    
    //Exit the code
    return 0;
}

