/*
 * File:   main.cpp
 * Author: Garrett Hileman
 * Created on March 14, 2022, 6:15 PM
 * Purpose: Paycheck
 */
//System Libraries

#include <iostream> //Input/Output Library
#include <iomanip> //Format Library 

using namespace std;

//User Libraries

//Global Constants
//Physics/Chemistry/Math/Conversion Higher Dimension Only

//Function Prototypes

// Program Execution Begins here
int main(int argc, char** argv) {
    //Set the Random Number Seed
    
    //Declare Variables
    int   payRa,   //pay rate in $'s/hr
          hrWrkd;  //hours worked
    float payChck; //Paycheck in $'s    
            
    
    //Initial Variables
    cout<<"This program calculates the gross paycheck."<<endl;
    cout<<"Input the pay rate in $'s/hr and the number of hours."<<endl;
    cin>>payRa>>hrWrkd;
    
    //Map the inputs to the outputs
    payChck =hrWrkd<40?
             hrWrkd*payRa:
        40*payRa+(hrWrkd-40)*2*payRa;
    
    //Display the inputs and outputs
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<"Paycheck = $"<<setw(7)<<payChck;
    
    //Exit the code
    return 0;
}