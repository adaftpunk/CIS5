/*
 * File:   main.cpp
 * Author: Garrett Hileman
 * Created on March 16, 2022, 7:44 PM
 * Purpose: Temp Conversion 
 */
//System Libraries

#include <iostream> //Input/Output Library
#include <iomanip> //Format Library

using namespace std;

//User Libraries

//Global Constants
//Physics/Chemistry/Math/Conversion Higher Dimension Only

//Function Prototypes

// Program Execution Begins here
int main(int argc, char** argv) {
    //Set the Random Number Seed
    
    //Declare Variables
    float F, //Fahrenheit
          C; //Celsius  
    
    //Initial Variables
    cout<<"Temperature Converter"<<endl;
    cout<<"Input Degrees Fahrenheit"<<endl;
    cin>>F;
    
    //Map the inputs to the outputs
     C=(F-32)*5/9;
    
    //Display the inputs and outputs
    cout<<fixed<<showpoint<<setprecision(1);
    cout<<F<<" Degrees Fahrenheit = "<<C<<" Degrees Centigrade";
    
    //Exit the code
    return 0;
}

