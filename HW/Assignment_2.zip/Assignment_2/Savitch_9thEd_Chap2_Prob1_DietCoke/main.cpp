/* 
 * File:   main.cpp
 * Author: Garrett Hileman
 * Created on March 10, 2022, 11:20 AM
 * Purpose: Diet Coke Problem 
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...
const float CNVLBSG=45359.2/100; //Conversion lbs to grams

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    float dsrdWt,    // desired weight
          msMass,    //mass of mouse
          msKill,    //mass of sweetner that kills mouse
          msCokCn,   //Mass of coke can
          cncntr8sn, //consenctration of sweetner in coke can
          wtKill,    //weight to kill
          dsKill,    //mass to kill deiter
          ms1Can;    //mass in one can
    int nCans;      //number of cans to kill      
    
    //Initialize or input i.e. set variable values
    cout<<"Program to calculate the limit of Soda Pop Consumption."<<endl;
    cout<<"Input the desired dieters weight in lbs."<<endl;
    cin>>dsrdWt;
    msMass=35;
    msKill=5;
    msCokCn=350;
    cncntr8sn=0.001f;
    
    //Map inputs -> outputs
    wtKill=msKill/msMass*dsrdWt;  //ration proportionality
    dsKill=wtKill*CNVLBSG;       //conversion to mass
    ms1Can=msCokCn*cncntr8sn;   //calculating the mass to sweetner in a can given concentration
    nCans=dsKill/ms1Can;       //how many cans of coke to cause possible death
    
    //Display the outputs
    cout<<"The maximum number of soda pop cans"<<endl;
    cout<<"which can be consumed is "<<nCans<<" cans";

    //Exit stage right or left!
    return 0;
}