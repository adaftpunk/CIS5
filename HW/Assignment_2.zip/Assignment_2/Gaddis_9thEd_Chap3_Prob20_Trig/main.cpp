/*
 * File:   main.cpp
 * Author: Garrett Hileman
 * Created on March 14, 2022, 6:24 PM
 * Purpose: Trig
 */
//System Libraries

#include <iostream> //Input/Output Library
#include <iomanip> //Format Library
#include <cmath>  //Math Library

using namespace std;

//User Libraries

//Global Constants
//Physics/Chemistry/Math/Conversion Higher Dimension Only
const float PI = atan(1)*4;
            

//Function Prototypes

// Program Execution Begins here
int main(int argc, char** argv) {
    //Set the Random Number Seed
    
    //Declare Variables
    int        anDeg; //angle in degrees
    float      anRad; //angle radians
    
    //Initial Variables
    cout<<"Calculate"<<setw(5)<<"trig"<<setw(10)<<"functions"<<endl;
    cout<<"Input"<<setw(4)<<"the"<<setw(6)<<"angle"
            <<setw(3)<<"in"<<setw(9)<<"degrees."<<endl;
    cin>>anDeg;
    
    //Map the inputs to the outputs
    anRad=(anDeg*PI)/180; //conversion to radians
    
    //Display the inputs and outputs
    cout<<fixed<<showpoint<<setprecision(4);
    
    cout<<"sin("<<anDeg<<")"<<setw(2)<<"="<<setw(7)<<sin(anRad)<<endl;
    cout<<"cos("<<anDeg<<")"<<setw(2)<<"="<<setw(7)<<cos(anRad)<<endl;
    cout<<"tan("<<anDeg<<")"<<setw(2)<<"="<<setw(7)<<tan(anRad);        
    
    
    
    //Exit the code
    return 0;
}

