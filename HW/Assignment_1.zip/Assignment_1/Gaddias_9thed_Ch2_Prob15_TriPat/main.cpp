/*
 * File:   main.cpp
 * Author: Garrett Hileman
 * Created on March 07, 2022, 11:14 PM
 * Purpose: Triangle Pattern
 */
//System Libraries

#include <iostream> //Input/Output Library
#include <cstdlib> //Random function
#include <ctime> //Time to set random number seed

using namespace std;

//User Libraries

//Global Constants
//Physics/Chemistry/Math/Conversion Higher Dimension Only

//Function Prototypes

// Program Execution Begins here
int main(int argc, char** argv) {
    //Set the Random Number Seed
    srand(static_cast<int>(time(0)));
    
    //Declare Variables
    char ltr;//Variable representing the letter to choose
    
    //Initial Variables
    ltr=rand()%26+65;//{A-Z} - {65-91}
    
    //Map the inputs to the outputs
    
    //Display the inputs and outputs
    cout<<"    "<<ltr<<endl;
    cout<<"   "<<ltr<<ltr<<ltr<<endl;
    cout<<"  "<<ltr<<ltr<<ltr<<ltr<<ltr<<endl;
    cout<<" "<<ltr<<ltr<<ltr<<ltr<<ltr<<ltr<<ltr;
    
    //Exit the code
    return 0;
}

