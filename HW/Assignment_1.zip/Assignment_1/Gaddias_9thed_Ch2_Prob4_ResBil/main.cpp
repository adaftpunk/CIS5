/*
 * File:   main.cpp
 * Author: Garrett Hileman
 * Created on March 07, 2022, 10:09 PM
 * Purpose: Restaurant Bill
 */
//System Libraries

#include <iostream> //Input/Output Library
#include <iomanip> //Format Library

using namespace std;

//User Libraries

//Global Constants
//Physics/Chemistry/Math/Conversion Higher Dimension Only

//Function Prototypes

// Program Execution Begins here
int main(int argc, char** argv) {
    //Set the Random Number Seed
    
    //Declare Variables
    float   meChar, //Meal Charge
            txRa, //Tax rate
            meTx, // Meal with tax
            tiRa, //Tip rate
            toTip, //Total tip
            totBil; //Total bill
    
    //Initial Variables
    meChar=88.67; //Meal Amount
    txRa=0.0675; //Tax rate
    tiRa=0.20;   //Tip rate  
    
    //Map the inputs to the outputs
            meTx=meChar*txRa;
            toTip=(meTx+meChar)*tiRa;
            totBil=meTx+toTip+meChar;
    
    //Display the inputs and outputs
            cout<<fixed<<setprecision(2);
      cout<<"This program shows the tax and tip on a $"
              <<meChar<<" restaurant bill"<<endl;
      cout<<"The tax amount is $"<<meTx<<" the tip amount is $"<<toTip<<endl;
      cout<<"The total bill is $"<<totBil;
      
    
    //Exit the code
    return 0;
}

