/* 
 * File:   main.cpp
 * Author: Garrett Hileman
 * Created on February 22, 2022, 11:30 AM
 * Purpose: Big C
 */
//System Libraries

#include <iostream> //Input Library
#include <cstdlib> //Random function
#include <ctime> //Time to set random number seed
using namespace std;

//User Libraries

//Global Constants

//Physics/Chemistry/Math/Conversion Higher Dimension Only

//Function Prototypes

// Program Execution Begins here

int main() {
    //Set the Random Number Seed
    srand(static_cast<int>(time(0)));
    
    //Declare Variables
    char ltr;//Variable representing the letter to choose
    
    //Initial Variables
    ltr=rand()%26+65;//{A-Z} - {65-91}
    //ltr='C';
    
    //Map the inputs to the outputs
    
    //Display the inputs and outputs
    cout<<"  "<<ltr<<ltr<<ltr<<endl;
    cout<<" "<<ltr<<"  "<<ltr<<endl;
    cout<<ltr<<endl;
    cout<<ltr<<endl;
    cout<<ltr<<endl;
    cout<<ltr<<endl;
    cout<<ltr<<endl;
    cout<<" "<<ltr<<"  "<<ltr<<endl;
    cout<<"  "<<ltr<<ltr<<ltr<<endl;
    
    //Exit the code
    return 0;
}

