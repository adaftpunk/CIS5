/*
 * File:   main.cpp
 * Author: Garrett Hileman
 * Created on March 07, 2022, 10:46 PM
 * Purpose: Circuit Board Price
 */
//System Libraries

#include <iostream> //Input/Output Library
#include <iomanip> //Format Library

using namespace std;

//User Libraries

//Global Constants
//Physics/Chemistry/Math/Conversion Higher Dimension Only

//Function Prototypes

// Program Execution Begins here
int main(int argc, char** argv) {
    //Set the Random Number Seed
    
    //Declare Variables
    float cirBoPri, //Circuit Board Price 
          proPer, //Profit Percent
          adPri, //Amount added to price 
          neTot; //New total  
    
    //Initial Variables
    cirBoPri=14.95;
    proPer=0.35;        
    
    //Map the inputs to the outputs
    adPri=cirBoPri*proPer;
    neTot=adPri+cirBoPri;
    
    //Display the inputs and outputs
    cout<<fixed<<setprecision(2);
    cout<<"This program calculates the new price of "
            "circuit boards at 35% markup"<<endl;
    cout<<"The new total is $"<<neTot;
    
    //Exit the code
    return 0;
}

