/*
 * File:   main.cpp
 * Author: Garrett Hileman
 * Created on February 24, 2022, 10:01 AM
 * Purpose: Land Calculation
 */
//System Libraries

#include <iostream> //Input/Output Library

using namespace std;

//User Libraries

//Global Constants
//Physics/Chemistry/Math/Conversion Higher Dimension Only
const float ACRFT2=43560;//Conversion from acres to ft^
const float FTMILE=5280;//Number of feet to a mile

//Function Prototypes

// Program Execution Begins here
int main(int argc, char** argv) {
    //Set the Random Number Seed
    
    //Declare Variables
    float ft2,//Area in ft2
          nAcres;//Number of acres
    
    //Initial Variables
    cout<<"This program performs land calculations"<<endl;
    cout<<"Input the square footage to convert"<<endl;
    cin>>ft2;
    
    //Map the inputs to the outputs
    nAcres=ft2/ACRFT2;
    
    //Display the inputs and outputs
    cout<<"The square footage = "<<ft2<<" ft^2"<<endl;
    cout<<"The number of acres = "<<nAcres<<" acres"<<endl;
    
    //Exit the code
    return 0;
}

