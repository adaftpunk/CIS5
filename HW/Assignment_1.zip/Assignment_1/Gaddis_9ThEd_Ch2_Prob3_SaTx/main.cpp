/*
 * File:   main.cpp
 * Author: Garrett Hileman
 * Created on February 28, 2022, 9:13 PM
 * Purpose: Sales Tax
 */
//System Libraries

#include <iostream> //Input/Output Library

using namespace std;

//User Libraries

//Global Constants
//Physics/Chemistry/Math/Conversion Higher Dimension Only

//Function Prototypes

// Program Execution Begins here
int main(int argc, char** argv) {
    //Set the Random Number Seed
    
    //Declare Variables
    float StaRa,//State Sales Tax Rate 
          CouRa,//County Sales Tax Rate  
          TotRa,//Total Tax rate
          TotTx,//Total Tax  
          PurAm;//Purchase Amount  
    
    //Initial Variables
            StaRa=0.04;//State Tax Rate Amount
            CouRa=0.02;//County Tax Rate Amount
            PurAm=95;//Purchase Amount Number
    
    //Map the inputs to the outputs
            TotRa=StaRa+CouRa,
            TotTx=TotRa*PurAm;        
    
    //Display the inputs and outputs
            cout<<"This program calculates the total tax of a $95 purchase"<<endl;
            cout<<"The total tax rate is "<<TotRa<<endl;
            cout<<"The total tax payed is $ "<<TotTx<<endl;
    
    //Exit the code
    return 0;
}

