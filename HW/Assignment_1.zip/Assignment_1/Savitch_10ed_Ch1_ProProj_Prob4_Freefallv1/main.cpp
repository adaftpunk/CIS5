/* 
 * File:   main.cpp
 * Author: Garrett Hileman
 * Created on February 22, 2022, 12:06 AM
 * Purpose: freefall
 */
//System Libraries

#include <iostream> //Input Library

using namespace std;

//User Libraries

//Global Constants
//Physics/Chemistry/Math/Conversion Higher Dimension Only
const float GRAVITY=32.174;//Acceleration due to gravity Units = ft/sec^2

//Function Prototypes

// Program Execution Begins here

int main() {
    //Set the Random Number Seed
    
    //Declare Variables
    float timFall, //time in free fall (secs)
          disFall;//distance in free fall (feet)
    
    //Initial Variables
    cout<<"This program calculates the distance drop in free fall"<<endl;
    cout<<"Assumes no drag!"<<endl;
    cout<<"Input the time in seconds"<<endl;
    cin>>timFall;
    
    //Map the inputs to the outputs
    disFall=GRAVITY*timFall*timFall/2;
    
    //Display the inputs and outputs
    cout<<"The distance fallen in "
            <<timFall<<" secs = "<<disFall<<" feet"<<endl;
    
    //Exit the code
    return 0;
}

