/*
 * File:   main.cpp
 * Author: Garrett Hileman
 * Created on March 7, 2022, 9:45 PM
 * Purpose: Averages
 */
//System Libraries

#include <iostream> //Input/Output Library

using namespace std;

//User Libraries

//Global Constants
//Physics/Chemistry/Math/Conversion Higher Dimension Only

//Function Prototypes

// Program Execution Begins here
int main(int argc, char** argv) {
    //Set the Random Number Seed
    
    //Declare Variables
    unsigned short int num1, // Number 28
                       num2, //Number 32
                       num3, //Number 37
                       num4, //Number 24
                       num5; // Number 33
    float average; //Average of the five numbers
    char numVal; //Number of variables
    
    //Initial Variables
    num1=28,num2=32,num3=37,num4=24,num5=33,
    numVal=5;        
    
    //Map the inputs to the outputs
    average=static_cast<float>(num1+num2+num3+num4+num5)/numVal;
    
    //Display the inputs and outputs
    cout<<"This program calculates the average of 5 variables"<<endl;
    cout<<"The variables are "<<
          num1<<","<<num2<<","<<num3<<","<<num4<<",and "<<num5<<endl;
    cout<<"The averages is "<<average;
    
    //Exit the code
    return 0;
}

