/*
 * File:   main.cpp
 * Author: Garrett Hileman
 * Created on February 24, 2022, 11:15 AM
 * Purpose: Change
 */
//System Libraries

#include <iostream> //Input/Output Library
#include <cstdlib> //Random Function
#include <ctime> //Time Library

using namespace std;

//User Libraries

//Global Constants
//Physics/Chemistry/Math/Conversion Higher Dimension Only
const unsigned char HLFDOLR=50;//Conversion from half dollar to pennies
const unsigned char QUARTER=25;//Conversion from Quarter to pennies
const unsigned char DIME=10;//Conversion from dime to pennies
const unsigned char NICKLE=5;//Conversion from nickle to pennies

//Function Prototypes

// Program Execution Begins here
int main(int argc, char** argv) {
    //Set the Random Number Seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare Variables
    unsigned short nHlfDls, //Number of half dollars
                   nQrts, //Number of quarters
                   nDimes, //Number of dimes
                   nNikls, //Number of nickles
                   nPenys, //Number of pennies
                   pktChng; //Total Pocket change 
    
    //Initial Variables
                   nHlfDls=rand()%10;//Range of random number {0-9}
                   nQrts=rand()%10;//Range of random number {0-9}
                   nDimes=rand()%10;//Range of random number {0-}]
                   nNikls=rand()%10;//Range of random number {0-9}
                   nPenys=rand()%10;//Range of random number {0-9}
    
    
    //Map the inputs to the outputs
                   pktChng = nHlfDls*HLFDOLR
                    +nQrts*QUARTER
                    +nDimes*DIME
                    +nNikls*NICKLE
                    +nPenys;
                   
    
    //Display the inputs and outputs
                   cout<<"The number of Half Dollars = "<<nHlfDls<<endl;
                   cout<<"The number of Quarters = "<<nQrts<<endl;
                   cout<<"The number of Dime = "<<nDimes<<endl;
                   cout<<"The number of Nickles = "<<nNikls<<endl;
                   cout<<"The number of Pennies = "<<nPenys<<endl;
                   cout<<"The Total Pocket Change = "<<pktChng<<" cents"<<endl;
    
    //Exit the code
    return 0;
}

