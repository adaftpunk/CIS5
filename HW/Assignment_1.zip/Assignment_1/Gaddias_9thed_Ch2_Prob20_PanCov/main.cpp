/* 
 * File:   main.cpp
 * Author: Garrett Hileman
 * Created on February 29, 2022, 10:05 PM
 * Purpose: Paint Coverage Problem
 */
//System Libraries

#include <iostream> //Input/Output Library

using namespace std;

//User Libraries

//Global Constants
//Physics/Chemistry/Math/Conversion Higher Dimension Only

//Function Prototypes

// Program Execution Begins here
int main(int argc, char** argv) {
    //Set the Random Number Seed
    
    //Declare Variables
    unsigned short fncLen, //Fence Length in feet
                   fncHgt, // Fence Hight in feet
                   ptCanCv, //Gallon of paint to cover ft^2
                   nmPtCns; //Number of paint cans required
    
    //Initial Variables
                   fncLen=100; //100 feet
                   fncHgt=6; //6 feet
                   ptCanCv=340; //340 ft^2
    
    //Map the inputs to the outputs
                   nmPtCns=4*fncLen*fncHgt/ptCanCv+1;
    
    //Display the inputs and outputs
                   cout<<"This program calculates the number of Cans of Paint"<<endl;
                   cout<<"required to paint a fence both sides twice"<<endl;
                   cout<< "Fence Length = "<<fncLen<<" feet"<<endl;
                   cout<<"Fence Height = "<<fncHgt<<" feet"<<endl;
                   cout<<"Paint coverage = "<<ptCanCv<<" feet^2/Gallon"<<endl;
                   cout<<"Number of Cans of Paint required = "<<nmPtCns<<endl;
    
    //Exit the code
    return 0;
}