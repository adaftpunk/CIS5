/*
 * File:   main.cpp
 * Author: Garrett Hileman
 * Created on March 03, 2022, 11:14 PM
 * Purpose: Military Budget
 */
//System Libraries

#include <iostream> //Input/Output Library

using namespace std;

//User Libraries

//Global Constants
//Physics/Chemistry/Math/Conversion Higher Dimension Only
const char PERCENT=100;//Percent Conversion

//Function Prototypes

// Program Execution Begins here
int main(int argc, char** argv) {
    //Set the Random Number Seed
    
    //Declare Variables
    float fedBdgt, //Federal Budget
          milBdgt, // Military Budget
          milPrct; //Military budget Percentage        
    
    //Initial Variables
    milBdgt=7.0e11f;//Military Budget = 700 Billion   
    fedBdgt=4.1e12f;//Federal Budget  = 4.1 Trillion
    
    //Map the inputs to the outputs
     milPrct=milBdgt/fedBdgt*PERCENT;
       
    //Display the inputs and outputs
    cout<<"The percentage of the federal budget"<<endl;
    cout<<"that was used on the military in 2018"<<endl;
    cout<<"is "<<milPrct<<"%";
    
    //Exit the code
    return 0;
}

