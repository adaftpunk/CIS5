/*
 * File:   main.cpp
 * Author: Garrett Hileman
 * Created on March 06, 2022, 11:01 PM
 * Purpose: Military Budget v2
 */
//System Libraries

#include <iostream> //Input/Output Library

using namespace std;

//User Libraries

//Global Constants
//Physics/Chemistry/Math/Conversion Higher Dimension Only
const char PERCENT=100;//Percent Conversion

//Function Prototypes

// Program Execution Begins here
int main(int argc, char** argv) {
    //Set the Random Number Seed
    
    //Declare Variables
    float fedBdgt, //Federal Budget
          milBdgt, // Military Budget
          milPrct; //Military budget Percentage        
    
    //Initial Variables
    milBdgt=705.4e9f;//Military Budget = 705.4 Billion   
    fedBdgt=6.8e12f;//Federal Budget  = 6.8 Trillion
    
    //Map the inputs to the outputs
     milPrct=milBdgt/fedBdgt*PERCENT;
       
    //Display the inputs and outputs
    cout<<"The percentage of the federal budget"<<endl;
    cout<<"that was used on the military in 2021"<<endl;
    cout<<"is "<<milPrct<<"%";
    
    //Exit the code
    return 0;
}

