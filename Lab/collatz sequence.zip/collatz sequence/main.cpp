/*
 * File:   main.cpp
 * Author: Garrett Hileman
 * Created on April 28, 2022, 11:37 AM
 * Purpose: collatz sequence
 */
//System Libraries

#include <iostream> //Input/Output Library

using namespace std;

//User Libraries

//Global Constants
//Physics/Chemistry/Math/Conversion Higher Dimension Only

//Function Prototypes
void thrNP1(unsigned int);//3n+1 collatz sequence

// Program Execution Begins here
int main(int argc, char** argv) {
    //Set the Random Number Seed
    
    //Declare Variables
    unsigned int seqStrt;
    
    //Initial Variables
    cout<<"this program outputs the Collatz Sequence"<<endl;
    cout<<"input the initial sequence value"<<endl;
    cin>>seqStrt;
    
    //Map the inputs to the outputs
    thrNP1(seqStrt);
    
    //Display the inputs and outputs
    
    //Exit the code
    return 0;
}

void thrNP1(unsigned int n){
    int cnt=-1;
    while(n>1){
        cout<<n<<" ";
        cnt++;
        if(cnt%10==9)cout<<endl;
        if(n%2==0){
            n/=2;
        }else{
           n=3*n+1; 
        }
    }
    cout<<n<<endl;
}