/*
 * File:   main.cpp
 * Author: Garrett Hileman
 * Created on March 08, 2022, 12:14 AM
 * Purpose: Savings Calculator
 */
//System Libraries

#include <iostream> //Input/Output Library
#include <cmath> //Power Function
#include <iomanip> //Formatted Decimal PLaces

using namespace std;

//User Libraries

//Global Constants
//Physics/Chemistry/Math/Conversion Higher Dimension Only
const unsigned char PERCENT=100;//conversion to percent

//Function Prototypes

// Program Execution Begins here
int main(int argc, char** argv) {
    //Set the Random Number Seed
    
    //Declare Variables
    float pv,     //Present Value
          intRate,//Interest rate  
          fv;     //Future Value
    unsigned char nCmpPds;//Number of compounding periods
    //Initial Variables
    pv=1e2f;    //$100
    intRate=6;  //6 percent
    nCmpPds=12; //12 years
    
    //Map the inputs to the outputs
    intRate/=PERCENT;
    fv=pv*pow((1+intRate),nCmpPds);
    
    //Display the inputs and outputs
    cout<<fixed<<setprecision(2);
    cout<<"$"<<fv<<" = "<<pv<<"*(1+"<<intRate<<")^"
            <<static_cast<int>(nCmpPds)<<endl;
    
    //Exit the code
    return 0;
}

