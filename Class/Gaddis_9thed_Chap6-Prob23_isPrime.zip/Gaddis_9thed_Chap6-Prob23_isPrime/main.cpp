/*
 * File:   main.cpp
 * Author: Garrett Hileman
 * Created on April 28, 2022, 10:04 AM
 * Purpose: Prime function
 */
//System Libraries

#include <iostream> //Input/Output Library
#include<cmath> //math library
#include <iomanip> //format library
#include <fstream> //file stream library

using namespace std;

//User Libraries

//Global Constants
//Physics/Chemistry/Math/Conversion Higher Dimension Only

//Function Prototypes
bool isPrime(unsigned int);

// Program Execution Begins here
int main(int argc, char** argv) {
    //Set the Random Number Seed
    
    //Declare Variables
    fstream out;
    unsigned int endPt, wide, cnt, perLine;
    
    //Initial Variables
    out.open("prime.dat",ios::out);
    cout<<"This program finds prime numbers"<<endl;
    cout<<"input a range of numbers n>1 to display list"<<endl;
    cout<<"Input an integer representing the end point of the range"<<endl;
    cin>>endPt;
    cout<<"input columns per a line"<<endl;
    cin>>perLine;
    
    //Map the inputs to the outputs
    //determine the width
    cout<<"all the prime numbers between 2 and "<<endPt<<endl<<endl;
    out<<"all the prime numbers between 2 and "<<endPt<<endl<<endl;
    wide=log(endPt)/log(10)+2; //power of 10 with 2 space buffer
    cnt=-1;
    for(int i=1;i<=endPt;i++){
        if(isPrime(i)){            
           cout<<setw(wide)<<i;
           out<<setw(wide)<<i;
           cnt++;
           if(cnt%perLine==(perLine-1)){//new row
            cout<<endl;
            out<<endl;
              }
            }  
       }
    cout<<endl;<<"there are "<<cnt<<"prime numbers < "<<endPt<<endl;
    out<<endl;<<"there are "<<cnt<<"prime numbers < "<<endPt<<endl;
    //clear up
    out.close();
    
    //Exit the code
    return 0;
}

bool isPrime(unsigned int n){
    //initialize variables, base conditions
    if (n==0 || n==1) return false; //not prime
    if (n==2) return true;//2 is prime
    unsigned int stpPnt=sqrt(n)+1; //stopping point in search of prime
    //loop to find multiplicative factor
    for(int test=2;test<=stpPnt;test++){
        if (n%test==0) return false;
    }
    return true;
}