/*
 * File:   main.cpp
 * Author: Garrett Hileman
 * Created on April 21, 2022, 9:46 AM
 * Purpose: Every way to write a function gaddis chap 6
 */
//System Libraries

#include <iostream> //Input/Output Library
#include <cmath> //math library
#include <iomanip> //format library
using namespace std;

//User Libraries

//Global Constants
//Physics/Chemistry/Math/Conversion Higher Dimension Only
const unsigned char PERCENT=100;//percent conversion

//Function Prototypes
float save1(float,float,int); //power function
float save2(float,float,int); //exp-log
float save3(float,float,int);//for-loop
float save4(float,float,int);//recursion
float save4(float,float,float);//same name
float save5(float,float,int=12);//defaulted parameter
void  save6(float &, float, int);//input/output parameter pass by reference 
int   save7(float &, float, int);//static variable

// Program Execution Begins here
int main(int argc, char** argv) {
    //Set the Random Number Seed
    
    //Declare Variables
    float pv, //present value in $'s
          intRate, //intrest rate
          fv; //future value
    int nCmp;
    
    //Initial Variables
    pv=100.0f; //100$
    intRate=6; //5%
    nCmp=72/intRate;//rule of 72 should 
    
    //Map the inputs to the outputs
    intRate/=PERCENT;
    
    //Display the inputs and outputs
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<"FV"<<pv<<","<<intRate<<","<<nCmp<<")"<<endl;
    cout<<"savings using math library pow = $"
            <<save1(pv,intRate,nCmp)<<endl;
    cout<<"savings using math library exp/log = $"
            <<save2(pv,intRate,nCmp)<<endl;
    cout<<"savings using for-loop = $"
            <<save3(pv,intRate,nCmp)<<endl;
    cout<<"savings using recursive = $"
            <<save4(pv,intRate,nCmp)<<endl;
    cout<<"savings using same name = $"
            <<save4(pv,intRate,static_cast<float>(nCmp))<<endl;
    cout<<"savings using defaulted parameter = $"
            <<save5(pv,intRate)<<endl;
    float pvfv=pv;
    save6(pv,intRate,nCmp);
     cout<<"savings using pass by reference = $"
            <<pvfv<<endl;
    for(int i=1,i<5;i++){
      pvfv=pv;
      save7(pv,intRate,nCmp);
     }
     pvfv=pv;
     int count=save7(pv,intRate,nCmp);
     cout<<"savings using pass by reference = $"
            <<pvfv<<endl;
     cout<<"the last function was called"<<count<<"times"<<endl;
    
    //Exit the code
    return 0;
}

//functions
float save1(float p, float i, int n){
    return p*pow(1+i,n);
}
float save2(float p, float i, int n){
    return p*exp(n*log(1+i));
}
float save3(float p, float i, int n){
    for(int j=0;i<n;j++){
        p*=(1+i);
    }
    return p;
}
float save4(float p, float i, int n){
    //base case
    if(n<=0)return p;
    //recursion
    return save4(p,i,n-1)*(1+i);
}
float save4(float p, float i, float n){
    return p*pow(1+i,n);
}
float save5(float p, float i, int n){
    for(int j=0;i<n;j++){
        p*=(1+i);
    }
    return p;
}
void save6(float &pvfv, float i, int n){
    for(int j=0;i<n;j++){
        pvfv*=(1+i);
    }
}
int save7(float &pvfv, float i, int n){
    static int count; //count keeps track of number of the times function 
                     //is called
    for(int j=0;i<n;j++){
        pvfv*=(1+i);
    }
    count++;
    return count;
}
